# scythian

Made by @donmccurdy, with [MagicaVoxel](https://ephtracy.github.io/).
